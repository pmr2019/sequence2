package com.example.todo.UI;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.todo.adapters.ItemAdapterList;
import com.example.todo.database.RoomProductHuntDb;
import com.example.todo.database.dao.ListDao;
import com.example.todo.database.dao.RequestDao;
import com.example.todo.model.ListeToDo;
import com.example.todo.R;
import com.example.todo.model.WaitingRequest;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.List;

public class ChoixListActivity extends AppCompatActivity implements ItemAdapterList.ActionListener {
    private EditText edtNewList;
    private Button btnAddList;
    private String token;
    private ItemAdapterList adapterList;
    private SharedPreferences settings;
    private ItemAdapterList.ActionListener al;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choix_list);
        btnAddList = (Button) findViewById(R.id.btnAddList);
        edtNewList = (EditText) findViewById(R.id.edtNewList);
        al = this;
        context = this;

        //Recovering the preferences and the token
        settings = PreferenceManager.getDefaultSharedPreferences(this);
        token = settings.getString("token", "");

        if (verifReseau()) {
            //Updating
            final RequestDao requestDao;
            requestDao = RoomProductHuntDb.getDatabase(context).requestDao();
            final List<WaitingRequest> waitingRequests = requestDao.getRequests();
            RequestQueue queue = Volley.newRequestQueue(this);
            for (final WaitingRequest r:waitingRequests) {
                final String url = r.getUrl();
                StringRequest stringRequest = new StringRequest(Request.Method.PUT, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                requestDao.delete(url);
                                Log.i("BlaBla",response.toString());
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i("Web", "error");
                    }
                });
                // Add the request to the RequestQueue.
                queue.add(stringRequest);
            }

            //Recovering the lists
            String url = settings.getString("api_url", "http://tomnab.fr/todo-api").toString() + "/lists?hash=" + token;
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Gson gson = new Gson();
                            JsonObject responseJson = gson.fromJson(response, JsonObject.class);
                            Type type = new TypeToken<List<ListeToDo>>() {
                            }.getType();
                            List<ListeToDo> lists = gson.fromJson(responseJson.getAsJsonArray("lists"), type);


                            //adapter parameters
                            adapterList = new ItemAdapterList(lists, al);

                            //Dao
                            final ListDao listDao;
                            listDao = RoomProductHuntDb.getDatabase(context).listDao();
                            //Saving
                            listDao.save(lists);

                            Log.i("BDD_sqlit", listDao.getLists().toString());

                            final RecyclerView recyclerView = findViewById(R.id.lists);
                            recyclerView.setLayoutManager(new LinearLayoutManager(context));
                            recyclerView.setAdapter(adapterList);
                            recyclerView.addItemDecoration(new DividerItemDecoration(context, LinearLayout.VERTICAL));
                            recyclerView.addItemDecoration((new DividerItemDecoration(context, LinearLayout.VERTICAL)));


                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.i("Web", "error");
                    Toast.makeText(context, "Error", Toast.LENGTH_LONG).show();
                }
            });
            // Add the request to the RequestQueue.
            queue.add(stringRequest);

        }
        else
        {
            //Dao
            final ListDao listDao;
            listDao = RoomProductHuntDb.getDatabase(context).listDao();
            List<ListeToDo> lists = listDao.getLists();

            //adapter parameters
            adapterList = new ItemAdapterList(lists, al);

            final RecyclerView recyclerView = findViewById(R.id.lists);
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            recyclerView.setAdapter(adapterList);
            recyclerView.addItemDecoration(new DividerItemDecoration(context, LinearLayout.VERTICAL));
            recyclerView.addItemDecoration((new DividerItemDecoration(context, LinearLayout.VERTICAL)));
        }

        // Click listener for Add button
        btnAddList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (verifReseau()){
                    String listTitle = edtNewList.getText().toString();
                    if (listTitle.equals("")) {
                        Toast myToast = Toast.makeText(getApplicationContext(), " Please name your list !", Toast.LENGTH_LONG);
                        myToast.show();
                    } else {
                        final ListeToDo[] newList = new ListeToDo[1];
                        //Add it to the DB
                        RequestQueue queue = Volley.newRequestQueue(context);
                        String url = settings.getString("api_url", "http://tomnab.fr/todo-api").toString() + "/lists?label=" + listTitle + "&hash=" + token;
                        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        Gson gson = new Gson();
                                        JsonObject responseJson = gson.fromJson(response, JsonObject.class);
                                        Type type = new TypeToken<ListeToDo>() {
                                        }.getType();
                                        newList[0] = gson.fromJson(responseJson.getAsJsonObject("list"), type);

                                        //Add it to the adapter
                                        adapterList.AddToList(newList[0]);

                                        //Add to the database
                                        final ListDao listDao;
                                        listDao = RoomProductHuntDb.getDatabase(context).listDao();
                                        //Saving
                                        listDao.add(newList[0]);


                                    }
                                }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Log.i("Web", "error");
                                Toast.makeText(context, "Error", Toast.LENGTH_LONG).show();
                            }
                        });
                        // Add the request to the RequestQueue.
                        queue.add(stringRequest);

                    }
                }

                else{
                    Toast.makeText(context, "There is no internet connection", Toast.LENGTH_LONG).show();
                }
                }


        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    //List clicked
    public void onListClicked(Integer idListe) {
        //Create an intent to move to ShowListActivity
        Intent toSecondAct = new Intent(ChoixListActivity.this, ShowListActivity.class);
        Bundle data_list = new Bundle();
        data_list.putInt("idList", idListe);
        toSecondAct.putExtras(data_list);
        startActivity(toSecondAct);
    }



    public boolean verifReseau() {
        // On vérifie si le réseau est disponible,
        // si oui on change le statut du bouton de connexion
        ConnectivityManager cnMngr = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cnMngr.getActiveNetworkInfo();

        String sType = "Aucun réseau détecté";
        Boolean bStatut = false;
        if (netInfo != null) {
            NetworkInfo.State netState = netInfo.getState();
            if (netState.compareTo(NetworkInfo.State.CONNECTED) == 0) {
                bStatut = true;
                int netType = netInfo.getType();
                switch (netType) {
                    case ConnectivityManager.TYPE_MOBILE:
                        sType = "Réseau mobile détecté";
                        break;
                    case ConnectivityManager.TYPE_WIFI:
                        sType = "Réseau wifi détecté";
                        break;
                }
            }
        }

        Log.i("Web", sType);
        return bStatut;
    }

}
