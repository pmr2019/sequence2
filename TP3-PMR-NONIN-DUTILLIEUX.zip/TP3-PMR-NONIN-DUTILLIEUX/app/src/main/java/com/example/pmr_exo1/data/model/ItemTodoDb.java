package com.example.pmr_exo1.data.model;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


@Entity(tableName = "items")
public class ItemTodoDb {
    
    @PrimaryKey
    private int id;
    private boolean fait;
    private String description;
    private int listeId;

    public void setFait(boolean fait) {
        this.fait = fait;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getListeId() {
        return listeId;
    }

    public boolean isFait() {
        return fait;
    }

    public void setListeId(int liste_id) {
        this.listeId = liste_id;
    }

    @NonNull
    @Override
    public String toString() {
        return "#"+id+" Liste#"+listeId;
    }
}
