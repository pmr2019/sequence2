package com.example.pmr_exo1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.Serializable;
import java.util.ArrayList;

public class ProfilListeTodo implements Serializable {

    private String login;
    private ArrayList<ListeTodo> mesListeTodo;

    public ProfilListeTodo(String login) {
        this.login = login;
        mesListeTodo = new ArrayList<ListeTodo>();

    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public ArrayList<ListeTodo> getMesListeTodo() {
        return mesListeTodo;
    }

    public void setMesListeTodo(ArrayList<ListeTodo> mesListeTodo) {
        this.mesListeTodo = mesListeTodo;
    }

    public void ajouterListe(ListeTodo liste){
        this.mesListeTodo.add(liste);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder().append("Listes de : " +this.login);
        for(ListeTodo listeTodo: this.mesListeTodo)
            sb.append("--").append(listeTodo);
        return sb.toString();
    }

    public String toJSON(boolean pretty){
        GsonBuilder gsonBuilder = new GsonBuilder()
                .serializeNulls()
                .disableHtmlEscaping();
        if(pretty) gsonBuilder.setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        return gson.toJson(this);
    }

    public static ProfilListeTodo fromJSON(String jsonString){
        Gson gson = new GsonBuilder()
                .serializeNulls()
                .disableHtmlEscaping()
                .create();
        return gson.fromJson(jsonString,ProfilListeTodo.class);
    }
}
