package com.example.pmr_exo1;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ItemTodoAdapter extends RecyclerView.Adapter<ItemTodoAdapter.ItemTodoViewHolder> {
    private static final String TAG = "Todo_ItemTodoAdapter";
    private List<ItemTodo> itemsTodoList;
    private CheckBoxManagerInterface cmi;
    public interface CheckBoxManagerInterface{
        void updateCheckbox(ItemTodo item, boolean isChecked, Callback<ItemResponse> callback);
        boolean isCheckable();
    }

    public ItemTodoAdapter(List<ItemTodo> itemsTodoList, CheckBoxManagerInterface cmi) {
        this.itemsTodoList = itemsTodoList;
        this.cmi = cmi;
    }

    @NonNull
    @Override
    public ItemTodoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //On inflate le template associé à un ItemTodo, et on retourne la vue correspondante.
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.item_todo_item, parent, false);
        return new ItemTodoViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final ItemTodoViewHolder holder, final int position) {
        final ItemTodo itemTodo = itemsTodoList.get(position);
        if(cmi.isCheckable())
        holder.checkbox.setOnCheckedChangeListener(null); //solve issue (Reset du onChangeListener)
        holder.checkbox.setText(itemTodo.getDescription());
        holder.checkbox.setChecked(itemTodo.isFait());
        holder.checkbox.setClickable(cmi.isCheckable());
        holder.checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {
                cmi.updateCheckbox(itemTodo, isChecked, new Callback<ItemResponse>() {
                    @Override
                    public void onResponse(Call<ItemResponse> call, Response<ItemResponse> response) {
                        if(response.isSuccessful()){
                            itemsTodoList.get(position).setFait(isChecked);
                        }
                        else
                            ((ParentActivity)cmi).alerter("Impossible de mettre à jour l'état de la checkbox");
                    }

                    @Override
                    public void onFailure(Call<ItemResponse> call, Throwable t) {
                        ((ParentActivity)cmi).alerter("Erreur de connexion à l'API - PUT check");
                    }
                });
                //Changement manuel de l'état de ItemTodo
                //La mise à jour complète et la persistance de donnée est faite dans la ShowListActivity
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemsTodoList.size();
    }

    class ItemTodoViewHolder extends RecyclerView.ViewHolder {
        public CheckBox checkbox;

        public ItemTodoViewHolder(@NonNull View itemView){
            super(itemView);
            checkbox = itemView.findViewById(R.id.checkBox);
        }

    }
}
