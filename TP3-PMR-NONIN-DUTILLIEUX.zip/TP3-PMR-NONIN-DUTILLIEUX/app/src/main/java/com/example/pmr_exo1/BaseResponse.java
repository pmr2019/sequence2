package com.example.pmr_exo1;

class BaseResponse {
    public boolean success;
    public int status;
    public String hash;
}
