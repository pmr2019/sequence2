package com.example.pmr_exo1.data.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.pmr_exo1.data.database.dao.ItemTodoDao;
import com.example.pmr_exo1.data.database.dao.ListeTodoDao;
import com.example.pmr_exo1.data.model.ItemTodoDb;
import com.example.pmr_exo1.data.model.ListeTodoDb;

@Database(entities = { ListeTodoDb.class, ItemTodoDb.class}, version = 6)
public abstract class RoomProvider extends RoomDatabase {

  public abstract ListeTodoDao listeTodoDao();
  public abstract ItemTodoDao itemTodoDao();

  //SINGLETON
  private static RoomProvider INSTANCE;

  public static RoomProvider getDatabase(final Context context) {
    if (INSTANCE == null) {
      synchronized (RoomProvider.class) {
        if (INSTANCE == null) {
          INSTANCE = Room.databaseBuilder(context.getApplicationContext(), RoomProvider.class,
              "RoomProvider").fallbackToDestructiveMigration().build();
        }
      }
    }
    return INSTANCE;
  }
}
