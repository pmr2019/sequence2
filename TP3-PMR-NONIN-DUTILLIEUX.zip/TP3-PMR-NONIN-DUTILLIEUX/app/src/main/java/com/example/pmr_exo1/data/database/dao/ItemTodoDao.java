package com.example.pmr_exo1.data.database.dao;

import android.content.ClipData;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.pmr_exo1.data.model.ItemTodoDb;
import java.util.List;

@Dao
public interface ItemTodoDao {

    //  @Query("SELECT * from items where")
    @Query("SELECT * FROM items WHERE listeId=:listeId") List<ItemTodoDb> getItems(int listeId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void save(List<ItemTodoDb> itemsTodo);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void save(ItemTodoDb itemTodo);

}
