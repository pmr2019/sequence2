package com.example.pmr_exo1.data.model;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "listes_todo")
public class ListeTodoDb {
    @PrimaryKey
    private long idApi;
    private String titre;
    private String date;


    public long getIdApi() {
        return idApi;
    }

    public void setIdApi(long idApi) {
        this.idApi = idApi;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
