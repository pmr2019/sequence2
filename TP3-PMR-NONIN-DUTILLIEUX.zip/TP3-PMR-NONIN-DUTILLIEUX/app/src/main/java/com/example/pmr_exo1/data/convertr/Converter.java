package com.example.pmr_exo1.data.convertr;

import com.example.pmr_exo1.ItemTodo;
import com.example.pmr_exo1.ListeTodo;
import com.example.pmr_exo1.data.model.ItemTodoDb;
import com.example.pmr_exo1.data.model.ListeTodoDb;

import java.util.ArrayList;
import java.util.List;

public class Converter {
    public ListeTodoDb from(ListeTodo listeTodo) {
        ListeTodoDb listeTodoDb = new ListeTodoDb();
        listeTodoDb.setIdApi(listeTodo.getId());
        listeTodoDb.setDate(listeTodo.getDate());
        listeTodoDb.setTitre(listeTodo.getTitreListeTodo());
        return listeTodoDb;
    }
    public List<ListeTodo> fromDb(List<ListeTodoDb> arrayListeTodoDb){
        ArrayList<ListeTodo> arrayListeTodo = new ArrayList<>();
        for (ListeTodoDb listeTodoDb : arrayListeTodoDb){
            arrayListeTodo.add(from(listeTodoDb));
        }
        return arrayListeTodo;
    }
    public List<ListeTodoDb> from(List<ListeTodo> arrayListeTodo) {
        ArrayList<ListeTodoDb> arrayListeTodoDb = new ArrayList<>();
        for (ListeTodo listeTodo : arrayListeTodo){
            arrayListeTodoDb.add(from(listeTodo));
        }
        return arrayListeTodoDb;
    }
    public ListeTodo from (ListeTodoDb listeTodoDb) {
        ListeTodo listeTodo = new ListeTodo();
        listeTodo.setId((int) listeTodoDb.getIdApi());
        listeTodo.setDate(listeTodoDb.getDate());
        listeTodo.setTitreListeTodo(listeTodoDb.getTitre());
        return listeTodo;
    }
    public ItemTodoDb from(ItemTodo itemTodo, int parentId){
        ItemTodoDb itemTodoDb = new ItemTodoDb();
        itemTodoDb.setFait(itemTodo.isFait());
        itemTodoDb.setDescription(itemTodo.getDescription());
        itemTodoDb.setListeId(parentId);
        itemTodoDb.setId(itemTodo.getId());
        return itemTodoDb;
    }
    public ItemTodo from(ItemTodoDb itemTodoDb){
        ItemTodo itemTodo = new ItemTodo();
        itemTodo.setFait(itemTodoDb.isFait());
        itemTodo.setDescription(itemTodoDb.getDescription());
        itemTodo.setId(itemTodoDb.getId());
        return itemTodo;
    }
    public List<ItemTodo> fromDb(List<ItemTodoDb> arrayItemTodoDb,int parentId){
        ArrayList<ItemTodo> arrayItemTodo = new ArrayList<>();
        for (ItemTodoDb itemTodoDb : arrayItemTodoDb){
            arrayItemTodo.add(from(itemTodoDb));
        }
        return arrayItemTodo;
    }
    public List<ItemTodoDb> from(List<ItemTodo> arrayItemTodo, int parentId) {
        ArrayList<ItemTodoDb> arrayItemTodoDb = new ArrayList<>();
        for (ItemTodo itemTodo : arrayItemTodo){
            arrayItemTodoDb.add(from(itemTodo,parentId));
        }
        return arrayItemTodoDb;
    }
}
