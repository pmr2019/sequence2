package com.example.pmr_exo1;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import com.example.pmr_exo1.data.convertr.Converter;
import com.example.pmr_exo1.data.database.RoomProvider;
import com.example.pmr_exo1.data.database.dao.ItemTodoDao;
import com.example.pmr_exo1.data.database.dao.ListeTodoDao;
import com.example.pmr_exo1.data.model.ItemTodoDb;
import com.example.pmr_exo1.data.model.ListeTodoDb;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.view.View.GONE;

public class ChoixListeActivity extends ParentActivity {

    private static final String CAT = "Todo_ChoixListeActivity"; //Catégorie de log
    private EditText input;
    private ArrayList<ListeTodo> lists;
    private String hash;
    private String pseudo;
    private ListeTodoDao listeTodoDao;
    private boolean online;
    private RecyclerView recyclerView;
    private ItemTodoDao itemTodoDao;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choix_liste);

        //Initialisation du todoService;
        initRetrofit();
        //Récupération du token d'identification et du pseudo
        online = getIntent().getStringExtra("mode").equals("online");
        hash = getIntent().getStringExtra("hash");
        pseudo = getIntent().getStringExtra("pseudo");

        //Récupération des éléments du layout
        recyclerView = findViewById(R.id.recycler_view);
        //_____________________ RECYCLER VIEW ________________________
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        // Set Activity label

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setVisibility(GONE);
        if(online) {
            this.setTitle("Listes de " + pseudo);
            fab.setVisibility(View.VISIBLE);

            //populated when todolists are fetched from API - cf populateActivity

            //_____________________ ALERT DIALOG BUILDER ________________________
            // Creating alert Dialog with one Button
            final AlertDialog.Builder alertDialog = new AlertDialog.Builder(ChoixListeActivity.this);
            // Setting Dialog Title
            alertDialog.setTitle(getResources().getString(R.string.add_list));

            //Ajout d'un EditText programmatiquement dans un AlertDialog
            alertDialog.setMessage(getResources().getString(R.string.list_name));
            input = new EditText(ChoixListeActivity.this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            input.setLayoutParams(lp);
            alertDialog.setView(input);

            //Gestion de la création d'une liste
            alertDialog.setPositiveButton(getResources().getString(R.string.create),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            //Si on créé une nouvelle liste, on récupère son nom
                            String listName = input.getText().toString();
                            if (listName.equals("")) { //On vérifie que les données soient cohérentes
                                Toast.makeText(ChoixListeActivity.this, R.string.empty_field, Toast.LENGTH_SHORT).show();
                            } else {//On créé la nouvelle liste et on l'ajoute aux préférences
                                addNewList(listName);
                            }
                            //Dans tous les cas on ferme la fenêtre de dialogue, et on vide l'EditText
                            dialog.dismiss();
                            alertDialog.create();
                            input.setText("");
                        }
                    });

            //Gestion de l'annulation de la création
            alertDialog.setNegativeButton(getResources().getString(R.string.cancel),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            input.setText("");
                        }
                    });

            final AlertDialog alert = alertDialog.create();

            //_____________________ ON NEW LIST CLICK ________________________
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alert.show();
                }
            });
        }
        listeTodoDao = RoomProvider.getDatabase(this).listeTodoDao();
        itemTodoDao = RoomProvider.getDatabase(this).itemTodoDao();

    }

    @Override
    public void onStart() {
        super.onStart();

        //Récupération des listes
        if(online){
            todoService.getLists(hash).enqueue(new Callback<ListResponse>() {
                @Override
                public void onResponse(Call<ListResponse> call, Response<ListResponse> response) {
                    if(response.isSuccessful() && response.body().success){
                        List<ListeTodo> arrayListeTodo = response.body().lists;
                        ChoixListeActivity.this.populateActivity(arrayListeTodo);
                        if(arrayListeTodo.isEmpty())
                            alerter("Vous n'avez pas encore de listes.");
                        else {
                            Converter convert = new Converter();
                            final List<ListeTodoDb> arrayListeTodoDb = convert.from(arrayListeTodo);
//                            listeTodoDao.clean();
                            new Thread(){
                                public void run() {
                                    listeTodoDao.save(arrayListeTodoDb);
                                    Log.d("TODO_", "run: save Dao");
                                    fetchItems(arrayListeTodoDb);
                                }
                            }.start();
                        }
                    }
                    else
                        alerter("Erreur lors du téléchargement des listes");
                }
                @Override
                public void onFailure(Call<ListResponse> call, Throwable t) {
                    alerter("Erreur de connexion à l'API");
                }
            });
        }
        else { //Offline
            new Thread() {
                public void run() {
                    Converter convert = new Converter();
                    List<ListeTodoDb> listeTodoDbs = listeTodoDao.getListesTodo();
                    final List<ListeTodo> arrayListeTodo = convert.fromDb(listeTodoDbs);
                    ChoixListeActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            populateActivity(arrayListeTodo);
                        }
                    });
                }
            }.start();
        }

    }

    private void fetchItems(List<ListeTodoDb> arrayListeTodoDb){
        for(ListeTodoDb listeTodoDb : arrayListeTodoDb) {
            final int idListeTodo = (int) listeTodoDb.getIdApi();
            todoService.getListItems(hash, idListeTodo).enqueue(new Callback<ListeTodo>() {
                @Override
                public void onResponse(Call<ListeTodo> call, Response<ListeTodo> response) {
                    if (response.isSuccessful()) {
                        final List<ItemTodoDb> itemsTodoDb = (new Converter()).from(response.body().getLesItems(), idListeTodo);
                        new Thread() {
                            public void run() {
                                itemTodoDao.save(itemsTodoDb);
                                Log.d("TODO_", "run: save items ");
                            }
                        }.start();
                    }
                }

                @Override
                public void onFailure(Call<ListeTodo> call, Throwable t) {

                }
            });
        }
    }

    //Permet de créer une nouvelle liste, de l'ajouter au ProfilListeTodo de l'activité, et de l'ajouter aux préférences
    private void addNewList(String listName) {
        //Mise à jour des données dans les préférences (on écrase les données précédentes)
        todoService.addList(hash,listName).enqueue(new Callback<ListResponse>() {
            @Override
            public void onResponse(Call<ListResponse> call, Response<ListResponse> response) {
                if(response.isSuccessful() && response.body().success) {
                    final ListeTodo responseList = response.body().list;
                    new Thread(){
                        public void run(){
                            listeTodoDao.save((new Converter()).from(responseList));
                        }
                    }.start();
                    ((ListeTodoAdapter) ChoixListeActivity.this.recyclerView.getAdapter()).addList(responseList);
                }
                else
                    alerter("La liste n'a pas pu être créée");
            }

            @Override
            public void onFailure(Call<ListResponse> call, Throwable t) {
                alerter("Erreur de connexion à l'API");
            }
        });
    }

    public void populateActivity(List<ListeTodo> listArray){
        lists = (ArrayList<ListeTodo>) listArray;
        recyclerView.setAdapter(new ListeTodoAdapter(lists, pseudo, online));
    }

}
