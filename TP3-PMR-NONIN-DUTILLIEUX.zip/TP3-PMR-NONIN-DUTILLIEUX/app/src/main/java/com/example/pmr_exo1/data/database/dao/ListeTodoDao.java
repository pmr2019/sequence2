package com.example.pmr_exo1.data.database.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.pmr_exo1.data.model.ListeTodoDb;

import java.util.List;

@Dao
public interface ListeTodoDao {

    //  @Query("SELECT * from items where")
    @Query("SELECT * FROM listes_todo") List<ListeTodoDb> getListesTodo();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void save(List<ListeTodoDb> listesTodo);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void save(ListeTodoDb listeTodo);

    @Query("DELETE FROM listes_todo") void clean();
}
