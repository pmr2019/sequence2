package com.example.pmr_exo1;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class ListeTodoAdapter extends RecyclerView.Adapter<ListeTodoAdapter.ListTodoViewHolder> {
    private static final String TAG = "Todo_ListeTodoAdapter";
    private List<ListeTodo> listeTodoList;
    private Context context;
    private String pseudo;
    private boolean online;

    public ListeTodoAdapter(List<ListeTodo> listeTodosList, String pseudo, boolean online) {
        this.listeTodoList = listeTodosList;
        this.pseudo = pseudo;
        this.online = online;
    }

    @NonNull
    @Override
    public ListTodoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //On inflate le template associé à une ListeTodo, et on retourne la vue correspondante.
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.liste_todo_item, parent, false);
        context = parent.getContext();
        return new ListTodoViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ListTodoViewHolder holder, final int position) {
        //On récupère la bonne ListeTodo. Afin de peupler à la vue déjà inflatée, on modifie ses contenus
        final ListeTodo listeTodo = listeTodoList.get(position);
        holder.title.setText(listeTodo.getTitreListeTodo());
        holder.metaData.setText("#"+listeTodo.getId());
        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lorsque l'on clique sur une ListeTodo, on démarre une ShoListActivity pour voir les items qu'elle contient

                //On démarre la nouvelle activité en envoyant le pseudo et l'index de la liste.
                Intent intent = new Intent(context, ShowListActivity.class);
                intent.putExtra("idListeTodo", listeTodo.getId());
                intent.putExtra("labelListeTodo", listeTodo.getTitreListeTodo());
                intent.putExtra("pseudo", pseudo);
                intent.putExtra("mode", online);

                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listeTodoList.size();
    }

    public void addList(ListeTodo list){
        listeTodoList.add(list);
        notifyItemInserted(getItemCount()-1);
    }

    //Classe interne ListTodoViewHolder utilisée pour créer les vues et y peupler les données des ListeTodo.
    class ListTodoViewHolder extends RecyclerView.ViewHolder{
        public TextView title, metaData;
        public LinearLayout parentLayout;

        public ListTodoViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            metaData = itemView.findViewById(R.id.listMetaData);
            parentLayout = itemView.findViewById(R.id.linear_layout);
        }
    }
}
