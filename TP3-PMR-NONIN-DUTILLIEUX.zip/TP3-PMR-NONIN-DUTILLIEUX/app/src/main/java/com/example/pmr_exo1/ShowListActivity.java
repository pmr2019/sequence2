package com.example.pmr_exo1;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;

import com.example.pmr_exo1.data.convertr.Converter;
import com.example.pmr_exo1.data.database.RoomProvider;
import com.example.pmr_exo1.data.database.dao.ItemTodoDao;
import com.example.pmr_exo1.data.model.ItemTodoDb;
import com.example.pmr_exo1.data.model.ListeTodoDb;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShowListActivity extends ParentActivity implements ItemTodoAdapter.CheckBoxManagerInterface {

    private static final String TAG = "Todo_ShowListActivity";
    private EditText edtItem = null;
    private ListeTodo listeTodo;
    private SharedPreferences.Editor editor;
    private RecyclerView recyclerView;
    private String hash;
    private String pseudo;
    private ItemTodoDao itemTodoDao;
    private int idListeTodo;
    boolean online = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list);


        //Initialisation du todoService;
        initRetrofit();

        //Récupération du token d'identification et du pseudo
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        editor = settings.edit();

        pseudo = settings.getString("pseudo","");
        hash = settings.getString("hash","");

        //Récupération de l'index de la ListeTodo (envoyé avec l'Intent de création d'activity depuis le ListeTodoAdapter)
        idListeTodo = this.getIntent().getIntExtra("idListeTodo",0);
        String label = this.getIntent().getStringExtra("labelListeTodo");
        online = this.getIntent().getBooleanExtra("mode", false);
        // Set Activity label
        listeTodo = new ListeTodo(label,null);
        listeTodo.setId(idListeTodo);
        this.setTitle(listeTodo.getTitreListeTodo());
        itemTodoDao = RoomProvider.getDatabase(this).itemTodoDao();
//        Log.d("DAO",itemTodoDao.getItems(idListeTodo).toString());

        //Récupération de toute la ListeTodo cliquée dans l'activité précédente grâce à l'API
        if(idListeTodo!=0) {
            if (online) {
                findViewById(R.id.message).setVisibility(View.GONE);
                findViewById(R.id.addItemWrapper).setVisibility(View.VISIBLE);
                todoService.getListItems(hash, idListeTodo).enqueue(new Callback<ListeTodo>() {
                    @Override
                    public void onResponse(Call<ListeTodo> call, Response<ListeTodo> response) {
                        if (response.isSuccessful()) {
                            List<ItemTodo> items = response.body().getLesItems();
                            final List<ItemTodoDb> itemsDb = (new Converter()).from(items,idListeTodo);
                            new Thread(){
                                public void run(){
                                    itemTodoDao.save(itemsDb);
                                    Log.d(TAG, "run: "+itemsDb.toString());

                                }
                            }.start();
                            populateActivity(items);
                        } else
                            alerter("Impossible de télécharger les items de liste.");
                    }

                    @Override
                    public void onFailure(Call<ListeTodo> call, Throwable t) {
                        alerter("Erreur de connexion à l'API");
                    }
                });
            } else { //Offline
                findViewById(R.id.addItemWrapper).setVisibility(View.GONE);
                findViewById(R.id.message).setVisibility(View.VISIBLE);
                new Thread() {
                    public void run() {
                        Converter convert = new Converter();
                        List<ItemTodoDb> itemTodoDbs = itemTodoDao.getItems(idListeTodo);

                        final List<ItemTodo> arrayItemTodo = convert.fromDb(itemTodoDbs,idListeTodo);
                        ShowListActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                populateActivity(arrayItemTodo);
                            }
                        });

                    }
                }.start();
            }

        }

        //_____________________ RECYCLER VIEW ________________________
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        //populate recyclerView's adapter on Retrofit call's callback

        //_____________________ ADD ITEM_TODO ________________________

        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);
        edtItem = findViewById(R.id.edtNewItem);
        fabAdd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                edtItem.onEditorAction(EditorInfo.IME_ACTION_DONE); //raise OnEditorActionListener
                edtItem.setText("");

            }
        });

        edtItem.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                final String descriptionNewItem = edtItem.getText().toString();
                if (descriptionNewItem.matches("")) {
                }
                else { //Si l'entrée est valide, ajout dun nouvel item à la liste
                    //traces.append(descriptionNewItem);
                    todoService.addListItem(hash,idListeTodo,descriptionNewItem).enqueue(new Callback<ItemResponse>() {
                        @Override
                        public void onResponse(Call<ItemResponse> call, Response<ItemResponse> response) {
                            if(response.isSuccessful() && response.body().success){
                                ItemTodo itemTodo = response.body().item;
                                Converter convert = new Converter();
                                final ItemTodoDb itemTodoDb = convert.from(itemTodo, idListeTodo);
                                listeTodo.ajouterItem(itemTodo);
                                recyclerView.getAdapter().notifyItemInserted(listeTodo.getLesItems().size());

                                new Thread(){
                                    public void run(){
                                        itemTodoDao.save(itemTodoDb);
                                    }
                                }.start();
                            }
                            else
                                alerter("Impossible d'insérer un nouvel item");
                        }

                        @Override
                        public void onFailure(Call<ItemResponse> call, Throwable t) {
                            alerter("Erreur de connexion à l'API - POST Item");
                        }
                    });
                }
                return false;
            }
        });

    }

    public void populateActivity(List<ItemTodo> items){
        listeTodo.setLesItems(items);
        recyclerView.setAdapter(new ItemTodoAdapter(items,this));
    }

    @Override
    public void updateCheckbox(ItemTodo item, boolean isChecked, Callback<ItemResponse> callback) {
        Converter convert = new Converter();
        final ItemTodoDb itemTodoDb = convert.from(item, idListeTodo);
        if(isChecked){
            todoService.checkItem(hash,idListeTodo,item.getId()).enqueue(callback);
        }
        else{
            todoService.uncheckItem(hash,idListeTodo,item.getId()).enqueue(callback);
        }

        new Thread(){
            public void run(){
                itemTodoDao.save(itemTodoDb);
            }
        }.start();
    }

    @Override
    public boolean isCheckable(){
        return online;
    }
}
