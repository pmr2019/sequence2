package com.example.pmr_exo1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;

import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ListeTodo implements Serializable {

    @SerializedName("items")
    private List<ItemTodo> lesItems;
    private int id;
    @SerializedName("label")
    private String titreListeTodo;
    private String date;

    public ListeTodo() {
        lesItems = new ArrayList<>();
        titreListeTodo = "";
    }

    public ListeTodo(String titreListeTodo, String date) {
        this.titreListeTodo = titreListeTodo;
        this.date = date;
        lesItems = new ArrayList<>();
    }

    public List<ItemTodo> getLesItems() {
        return lesItems;
    }

    public void setLesItems(List<ItemTodo> lesItems) {
        this.lesItems = lesItems;
    }

    public String getTitreListeTodo() {
        return titreListeTodo;
    }

    public void setTitreListeTodo(String titreListeTodo) {
        this.titreListeTodo = titreListeTodo;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ItemTodo rechercherItem(String descriptionItem){
        for(ItemTodo item: this.lesItems)
            if(item.getDescription().equals(descriptionItem))
                return item;
        return null;
    }

    public void ajouterItem(ItemTodo item){
        this.lesItems.add(item);
    }

    @Override
    public String toString() {
        return "ListeTodo{" +
                "lesItems=" + lesItems +
                ", titreListeTodo='" + titreListeTodo + '\'' +
                ", listMetaData='" + date + '\'' +
                '}';
    }

    public String toJSON(boolean pretty){
        GsonBuilder gsonBuilder = new GsonBuilder()
                .serializeNulls()
                .disableHtmlEscaping();
        if(pretty) gsonBuilder.setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        return gson.toJson(this);
    }

    public static ListeTodo fromJSON(String jsonString){
        Gson gson = new GsonBuilder()
                .serializeNulls()
                .disableHtmlEscaping()
                .create();
        return gson.fromJson(jsonString,ListeTodo.class);
    }

}
