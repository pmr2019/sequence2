package com.example.pmr_exo1;

class ItemResponse extends BaseResponse{
    public ItemTodo item;
}
