package com.example.pmr_exo1;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ItemTodo implements Serializable {

    private int id;
    @SerializedName("checked")
    private String fait;
    @SerializedName("label")
    private String description;

    public ItemTodo(String description, boolean fait) {
        this.setFait(fait);
        this.setDescription(description);
    }
    public ItemTodo(String description) {
        this(description,false);
    }
    public ItemTodo() {
        this("",false);
    }

    public boolean isFait() {
        return fait.equals("1");
    }

    public void setFait(boolean fait) {
        this.fait = fait?"1":"0";
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "\""+this.description+"\" : "+ (this.fait.equals("1") ? "Fait" : "Pas fait");
    }
}
