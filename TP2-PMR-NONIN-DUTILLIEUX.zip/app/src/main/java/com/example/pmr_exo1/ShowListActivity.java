package com.example.pmr_exo1;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.Callable;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShowListActivity extends ParentActivity implements ItemTodoAdapter.CheckBoxManagerInterface {

    private static final String TAG = "Todo_ShowListActivity";
    private EditText edtItem = null;
    private ListeTodo listeTodo;
    private SharedPreferences.Editor editor;
    private RecyclerView recyclerView;
    private String hash;
    private String pseudo;
    private int idListeTodo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list);


        //Initialisation du todoService;
        initRetrofit();

        //Récupération du token d'identification et du pseudo
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        editor = settings.edit();

        pseudo = settings.getString("pseudo","");
        hash = settings.getString("hash","");

        //Récupération de l'index de la ListeTodo (envoyé avec l'Intent de création d'activity depuis le ListeTodoAdapter)
        idListeTodo = this.getIntent().getIntExtra("idListeTodo",0);
        String label = this.getIntent().getStringExtra("labelListeTodo");

        // Set Activity label
        listeTodo = new ListeTodo(label,null);
        this.setTitle(listeTodo.getTitreListeTodo());

        //Récupération de toute la ListeTodo cliquée dans l'activité précédente grâce à l'API
        if(idListeTodo!=0) {
            todoService.getListItems(hash,idListeTodo).enqueue(new Callback<ListeTodo>() {
                @Override
                public void onResponse(Call<ListeTodo> call, Response<ListeTodo> response) {
                    if(response.isSuccessful()){
                        populateActivity(response.body());
                    }
                    else
                        alerter("Impossible de télécharger les items de liste.");
                }

                @Override
                public void onFailure(Call<ListeTodo> call, Throwable t) {
                    alerter("Erreur de connexion à l'API");
                }
            });

        }

        //_____________________ RECYCLER VIEW ________________________
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        //populate recyclerView's adapter on Retrofit call's callback

        //_____________________ ADD ITEM_TODO ________________________

        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);
        edtItem = findViewById(R.id.edtNewItem);
        fabAdd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.i(TAG, "onClick bouton + : " + v);
                edtItem.onEditorAction(EditorInfo.IME_ACTION_DONE); //raise OnEditorActionListener
                edtItem.setText("");

            }
        });

        edtItem.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                Log.i(TAG, "onEditorAction");
                final String descriptionNewItem = edtItem.getText().toString();
                if (descriptionNewItem.matches("")) {
                    Log.i(TAG, "L'utilisateur entre une todoItem vide !");
                }
                else { //Si l'entrée est valide, ajout dun nouvel item à la liste
                    //traces.append(descriptionNewItem);
                    todoService.addListItem(hash,idListeTodo,descriptionNewItem).enqueue(new Callback<ItemResponse>() {
                        @Override
                        public void onResponse(Call<ItemResponse> call, Response<ItemResponse> response) {
                            if(response.isSuccessful() && response.body().success){
                                listeTodo.ajouterItem(response.body().item);
                                recyclerView.getAdapter().notifyItemInserted(listeTodo.getLesItems().size());
                            }
                            else
                                alerter("Impossible d'insérer un nouvel item");
                        }

                        @Override
                        public void onFailure(Call<ItemResponse> call, Throwable t) {
                            alerter("Erreur de connexion à l'API - POST Item");
                        }
                    });
                }
                return false;
            }
        });

    }

    public void populateActivity(ListeTodo list){
        listeTodo.setLesItems(list.getLesItems());
        recyclerView.setAdapter(new ItemTodoAdapter(listeTodo.getLesItems(),this));
    }

    @Override
    public void updateCheckbox(int idItem, boolean isChecked, Callback<ItemResponse> callback) {
        if(isChecked){
            todoService.checkItem(hash,idListeTodo,idItem).enqueue(callback);
        }
        else{
            todoService.uncheckItem(hash,idListeTodo,idItem).enqueue(callback);
        }
    }
}
