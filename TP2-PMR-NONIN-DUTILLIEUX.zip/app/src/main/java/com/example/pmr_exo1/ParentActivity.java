package com.example.pmr_exo1;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public class ParentActivity extends AppCompatActivity {

    public final String CAT="Todo_ParentActivity";
    protected Retrofit retrofit;
    protected TodoApiService todoService;

    protected void initRetrofit(){
        SharedPreferences settings =
                PreferenceManager.getDefaultSharedPreferences(this);

        String baseURl = settings.getString("api_url","");

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseURl)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        todoService = retrofit.create(TodoApiService.class);
    }

    protected void alerter(String s) {
        Log.i(CAT,s);
        Toast myToast = Toast.makeText(this,s,Toast.LENGTH_SHORT);
        myToast.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.action_account :
                alerter("Menu Compte");
                break;

            case R.id.action_settings :

                alerter("Menu Préférences");
                Intent toSettings = new Intent(this,SettingsActivity.class);
                startActivity(toSettings);
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    //Méthode de test de la sérialisation JSON des listes. Inutilisée en production.
    public String testListeToJSON(){
        ListeTodo maListe = new ListeTodo();
        for(int i=1; i<5;i++)
            maListe.ajouterItem(new ItemTodo("Todo n°"+i));
        //TODO : Afficher la liste dans le Log CAT
        Log.i(CAT,maListe.toString());
        // TODO: Sérialiser la liste
        Log.i(CAT,maListe.toJSON(true));
        Log.i(CAT,maListe.toJSON(false));

        return maListe.toJSON(false);
    }


    private String convertStreamToString(InputStream in) throws IOException {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            return sb.toString();
        }finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public boolean verifReseau()
    {
        // On vérifie si le réseau est disponible,
        // si oui on change le statut du bouton de connexion
        ConnectivityManager cnMngr = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cnMngr.getActiveNetworkInfo();

        String sType = "Aucun réseau détecté";
        Boolean bStatut = false;
        if (netInfo != null)
        {

            NetworkInfo.State netState = netInfo.getState();

            if (netState.compareTo(NetworkInfo.State.CONNECTED) == 0)
            {
                bStatut = true;
                int netType= netInfo.getType();
                switch (netType)
                {
                    case ConnectivityManager.TYPE_MOBILE :
                        sType = "Réseau mobile détecté"; break;
                    case ConnectivityManager.TYPE_WIFI :
                        sType = "Réseau wifi détecté"; break;
                }

            }
        }

        this.alerter(sType);
        return bStatut;
    }

    public String requete(String qs) {
        if (qs != null)
        {
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
            String urlData = prefs.getString("urlData","http://10.0.2.2/android_chat/data.php");

            try {
                URL url = new URL(urlData + "?" + qs);
                Log.i(CAT,"url utilisée : " + url.toString());
                HttpURLConnection urlConnection = null;
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = null;
                in = new BufferedInputStream(urlConnection.getInputStream());
                String txtReponse = convertStreamToString(in);
                urlConnection.disconnect();
                return txtReponse;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return "";
    }
    /**________________RETROFIT CONFIGURATION_______________**/
    public interface TodoApiService {
        @POST("authenticate")
        Call<BaseResponse> authenticate(@Query("user") String user, @Query("password") String password);

        @GET("lists")
        Call<ListResponse> getLists(@Header("hash") String hash);

        @POST("lists")
        Call<ListResponse> addList(@Header("hash") String hash, @Query("label") String label);

        @GET("lists/{id}/items")
        Call<ListeTodo> getListItems(@Header("hash") String hash, @Path("id") int id);

        @POST("lists/{id}/items")
        Call<ItemResponse> addListItem(@Header("hash") String hash, @Path("id") int id, @Query("label") String label);

        @PUT("lists/{idListe}/items/{idItem}?check=1")
        Call<ItemResponse> checkItem(@Header("hash") String hash, @Path("idListe") int idListe, @Path("idItem") int idItem);

        @PUT("lists/{idListe}/items/{idItem}?check=0")
        Call<ItemResponse> uncheckItem(@Header("hash") String hash, @Path("idListe") int idListe, @Path("idItem") int idItem);


    }
}
