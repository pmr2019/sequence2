package com.example.pmr_exo1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends ParentActivity implements View.OnClickListener {

    public final String CAT="Todo_MainActivity";

    private EditText edtPseudo = null;
    private Button btnOK = null;
    private EditText edtPassword = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtPseudo = findViewById(R.id.edtPseudo);
        edtPassword = findViewById(R.id.edtPassword);

        btnOK = findViewById(R.id.btnOK);

        edtPseudo.setOnClickListener(this);
        btnOK.setOnClickListener(this);
        btnOK.setVisibility(View.GONE);

     }

    @Override
    protected void onStart() {
        super.onStart();
        // récupération des préférences au niveau Application
        SharedPreferences settings =
                PreferenceManager.getDefaultSharedPreferences(this);

        edtPseudo.setText(settings.getString("pseudo",""));
        edtPassword.setText(settings.getString("password",""));
        initRetrofit(); //hérité de la classe ParentActivity et permet l'initialisation de todoService (ParentActivity également)
    }
    @Override
    protected void onResume() {
        super.onResume();
        this.updateBtnVisibility();
    }

    @Override
    public void onClick(View v) {
        //alerter("clic par l'activité qui implémente l'interface onClickListener");
        // Intérêt : permet de capturer des clics sur plusieurs éléments...
        // Démonstration :
        switch (v.getId()) {
            case R.id.btnOK :
                // On récupère l'heure de la tentative de connexion, le pseudo et le mot de passe utilisé
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                final String dateLogin = sdf.format(new Date());
                final String pseudo = edtPseudo.getText().toString();
                final String password = edtPassword.getText().toString();

                todoService.authenticate(pseudo,password).enqueue(new Callback<BaseResponse>() {
                    @Override
                    public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                        if(response.isSuccessful() && response.body().success){
                            final String hash = response.body().hash;
                            //On sauvegarde les informations de connexions seulement si la connexion réussit.
                            MainActivity.this.persistCredentials(pseudo,password,dateLogin,hash);

                            alerter("Connexion réussie!");

                            //Lancement de l'activité ChoixListeActivity
                            Intent intentChoixListeActivity = new Intent(MainActivity.this, ChoixListeActivity.class);
                            intentChoixListeActivity.putExtra("hash",hash);
                            intentChoixListeActivity.putExtra("pseudo",pseudo);
                            startActivity(intentChoixListeActivity);
                        }
                        else
                            alerter("Erreur d'authentification");
                    }

                    @Override
                    public void onFailure(Call<BaseResponse> call, Throwable t) {
                        alerter("Erreur de connexion à l'API");
                    }
                });
                break;

            case R.id.edtPseudo : //Si on clique sur le champ de texte
                alerter("Saisir votre pseudo"); //Alors on affiche un toast
                break;
        }
    }

    public void updateBtnVisibility(){
        if(verifReseau())
            btnOK.setVisibility(View.VISIBLE);
        else
            btnOK.setVisibility(View.GONE);
    }
    public void persistCredentials(String pseudo, String password, String dateLogin, String hash){
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = settings.edit();
        // Dans tous les cas, on enregistre le pseudo actuel comme pseudo par défaut dans les préférences
        editor.putString("pseudo",pseudo);
        editor.putString("password",password);
        editor.putString("dateLogin",dateLogin);
        editor.putString("hash",hash);
        //On commit toutes les modifications du fichier de préférence.
        editor.commit();

    }
}
