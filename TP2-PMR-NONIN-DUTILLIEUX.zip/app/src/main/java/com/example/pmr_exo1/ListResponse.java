package com.example.pmr_exo1;

import java.util.ArrayList;

class ListResponse extends BaseResponse {
    public ArrayList<ListeTodo> lists; //GET multiple lists
    public ListeTodo list;             //Response to a POST : the freshly created list
}
